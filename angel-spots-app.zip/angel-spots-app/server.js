const express = require('express');
const { createClient } = require('@libsql/client');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// --- Datenbank (Turso) ---
if (!process.env.TURSO_DATABASE_URL || !process.env.TURSO_AUTH_TOKEN) {
  console.error('\n❌ Fehlende Umgebungsvariablen: TURSO_DATABASE_URL und TURSO_AUTH_TOKEN müssen gesetzt sein.\n');
  process.exit(1);
}

const db = createClient({
  url: process.env.TURSO_DATABASE_URL,
  authToken: process.env.TURSO_AUTH_TOKEN,
});

async function initDb() {
  await db.execute(`
    CREATE TABLE IF NOT EXISTS spots (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      level TEXT,
      time TEXT,
      golden TEXT,
      map_image TEXT,
      created_at INTEGER
    )
  `);
  await db.execute(`
    CREATE TABLE IF NOT EXISTS fish (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      spot_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      time TEXT
    )
  `);
}

app.use(express.json({ limit: '15mb' })); // groß genug für Kartenbilder als Base64
app.use(express.static(path.join(__dirname, 'public')));

// --- API: Spots lesen (inkl. Fische) ---
app.get('/api/spots', async (req, res) => {
  try {
    const spotsResult = await db.execute('SELECT * FROM spots ORDER BY created_at DESC');
    const fishResult = await db.execute('SELECT * FROM fish');

    const fishBySpot = {};
    for (const f of fishResult.rows) {
      if (!fishBySpot[f.spot_id]) fishBySpot[f.spot_id] = [];
      fishBySpot[f.spot_id].push({ id: f.id, name: f.name, time: f.time });
    }

    const result = spotsResult.rows.map(s => ({
      id: s.id,
      name: s.name,
      level: s.level,
      time: s.time,
      golden: s.golden,
      mapImage: s.map_image,
      fish: fishBySpot[s.id] || []
    }));
    res.json(result);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Datenbankfehler' });
  }
});

// --- API: Spot anlegen ---
app.post('/api/spots', async (req, res) => {
  try {
    const { name, level, time, golden, mapImage } = req.body;
    if (!name || !name.trim()) return res.status(400).json({ error: 'Name erforderlich' });

    const result = await db.execute({
      sql: 'INSERT INTO spots (name, level, time, golden, map_image, created_at) VALUES (?, ?, ?, ?, ?, ?)',
      args: [name.trim(), level || '', time || '', golden || '', mapImage || null, Date.now()]
    });
    res.json({ id: Number(result.lastInsertRowid) });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Datenbankfehler' });
  }
});

// --- API: Spot löschen ---
app.delete('/api/spots/:id', async (req, res) => {
  try {
    await db.execute({ sql: 'DELETE FROM fish WHERE spot_id = ?', args: [req.params.id] });
    await db.execute({ sql: 'DELETE FROM spots WHERE id = ?', args: [req.params.id] });
    res.json({ ok: true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Datenbankfehler' });
  }
});

// --- API: Kartenbild eines Spots setzen/entfernen ---
app.put('/api/spots/:id/map', async (req, res) => {
  try {
    const { mapImage } = req.body;
    await db.execute({
      sql: 'UPDATE spots SET map_image = ? WHERE id = ?',
      args: [mapImage || null, req.params.id]
    });
    res.json({ ok: true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Datenbankfehler' });
  }
});

// --- API: Fisch hinzufügen ---
app.post('/api/spots/:id/fish', async (req, res) => {
  try {
    const { name, time } = req.body;
    if (!name || !name.trim()) return res.status(400).json({ error: 'Name erforderlich' });

    const result = await db.execute({
      sql: 'INSERT INTO fish (spot_id, name, time) VALUES (?, ?, ?)',
      args: [req.params.id, name.trim(), time || '']
    });
    res.json({ id: Number(result.lastInsertRowid) });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Datenbankfehler' });
  }
});

// --- API: Fisch löschen ---
app.delete('/api/spots/:spotId/fish/:fishId', async (req, res) => {
  try {
    await db.execute({
      sql: 'DELETE FROM fish WHERE id = ? AND spot_id = ?',
      args: [req.params.fishId, req.params.spotId]
    });
    res.json({ ok: true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Datenbankfehler' });
  }
});

initDb()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`\n✅ Server läuft: http://localhost:${PORT}\n`);
    });
  })
  .catch(err => {
    console.error('❌ Datenbank-Initialisierung fehlgeschlagen:', err);
    process.exit(1);
  });
